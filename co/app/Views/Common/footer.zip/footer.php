<section class="section7">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-6">
						<div class="foot">
							<div class="foot1">
								<h5 class="foot2 foot9">Shop Non-Stop on Meesho</h5>
								<p class="foot3">Trusted by more than 1 Crore Indians<br>
								Cash on Delivery | Free Delivery</p>
								<div class="foot4">
									<div class="foot5">
										<img style="width:100%"src="<?php echo base_url('public/image/demo17.png');?>">
									</div>
									<div class="foot5">
										<img style="width:100%"src="<?php echo base_url('public/image/dem019.png');?>">
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6">
						<div class="foot">
							<p class="foot6">Careers</p>
							<p class="foot6">Become a supplier</p>
							<p class="foot6">Our Influencer Program</p>
							<p class="foot6">Hall of Fame</p>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 bh">
						<div class="foot">
							<h4 class="foot2">Reach out to us </h4>
							<div class="foot8">
								<i class="fa-brands fa-facebook rc rc1"></i>
								<i class="fa-brands fa-instagram rc rc4"></i>
								<i class="fa-brands fa-youtube rc rc3"></i>
								<i class="fa-brands fa-linkedin rc rc2"></i>
								<i class="fa-brands fa-twitter rc rc1"></i>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6">
						<div class="foot">
							<h4 class="foot2">Contact Us</h4>
							<p class="foot7">Fashnear Technologies Private Limited,
							CIN: U74900KA2015PTC082263
							06-105-B, 06-102, (138 Wu) Vaishnavi Signature, No. 78/9, Outer Ring Road, Bellandur, Varthur Hobli, Bengaluru-560103, Karnataka, India
							E-mail address: query@meesho.com
							© 2015-2022 Meesho.com</p>
						</div>
					</div>
				</div>
				<!--dropdownfooter-->
				<?php echo  view('common/dropdownfooter');?>
				<!--dropdownfooter-->
			</div>
		</section>